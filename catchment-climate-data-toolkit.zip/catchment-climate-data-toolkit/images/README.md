# Images

Add screenshots generated from your own project here.

Recommended files:
- `catchment_map.png` — screenshot of the interactive watershed map
- `prism_timeseries.png` — precipitation/temperature output figure

Then reference them from the main README with:

    ![Catchment delineation](images/catchment_map.png)
