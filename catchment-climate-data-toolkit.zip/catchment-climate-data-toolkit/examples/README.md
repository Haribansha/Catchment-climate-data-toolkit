# Examples

After running the notebook, copy a small representative set of generated outputs here if you want visitors to inspect them.

Recommended:
- `example_catchment.geojson`
- `example_outlet.geojson`
- a short (e.g., one-month) PRISM CSV

Avoid committing thousands of raw PRISM raster files.
